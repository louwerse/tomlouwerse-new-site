This is a development version of the Dutch Parliamentary Behaviour Dataset (Voting Dataset).

The codebook for the last stable version is included, which should be adequate for the current version.

Please use the citations available in the codebook if you make use of this dataset.
